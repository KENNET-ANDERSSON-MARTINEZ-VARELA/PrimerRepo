"String"

"""Tus datos estos
    la mayonesa
    la guacamole"""

True
False 
"datos boleanos true o false"
