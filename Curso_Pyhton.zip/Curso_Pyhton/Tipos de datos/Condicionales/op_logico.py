#And

Resultado = True & False  #Devuelve False

# OR

Resultad = True | False  # Devuelve True

# NOT 

resultado = not True # Devolver False
resultad = not False # Devolver True