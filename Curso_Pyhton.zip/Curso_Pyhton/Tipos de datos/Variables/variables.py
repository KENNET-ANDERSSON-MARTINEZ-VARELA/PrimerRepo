a = 9

numero = 10
numero += 3

print(numero)

nombre = "Mario"
nombre = "Pedro"

#Concatenar con +
bienvenido = "Hola " + nombre + " ¿Como estas?"

print(bienvenido)

#operadores de pertenencia (in/not in)

print("Pedro" in bienvenido) #True

print("Pedro" not in bienvenido) #False
