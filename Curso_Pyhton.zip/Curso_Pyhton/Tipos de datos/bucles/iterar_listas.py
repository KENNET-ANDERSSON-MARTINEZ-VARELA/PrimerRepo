animales = ["gato","perro","loro","cocodrilo"]
numeros = [23,378,372]


for animal in animales:
    print(f'Se encuentran estos animales: {animal}')
    
    
for numero in numeros:
    resultado = numero * 10
    print(resultado)
 
 #recorrer una lista   
for num in enumerate(numeros):
    indice = num[0]
    valor = num[1]
    print(f'el indice es: {indice} y el valor es: {valor}')
    
#usando el else
for numero in numeros:
    print(f'ejecutando el ultimo bucle, valor actual: {numero}')
else:
    print("bucle terminado")
    
    

