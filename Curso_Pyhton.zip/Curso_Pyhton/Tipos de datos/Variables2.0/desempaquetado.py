#Creando los datos
datos_en_tupla = {"Kennet","Dalto",100000}
datos_en_lista = ["Kennet","Dalto",100000]

#Desempaquetado
nombre, apellido, suscriptores = datos_en_lista

#Mostrando resultados
print(suscriptores)