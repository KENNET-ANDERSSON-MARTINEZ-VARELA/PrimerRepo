#creando un conjunto set

conjunto = set(["Dato 1"])

#Metiendo un conjunto dentro de otro
conjunto1 = frozenset(["dato 1","dato 2"])
conjunto2 = {conjunto1, "dato 3"}

print(conjunto2)