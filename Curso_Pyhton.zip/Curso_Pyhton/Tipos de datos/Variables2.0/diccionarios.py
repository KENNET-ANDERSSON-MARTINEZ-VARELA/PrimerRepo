diccionario = dict(nombre="Kennet",apellido="Martinez")

#Las listas no pueden ser claves usando{}

#creando diccionario con fromkeys() 
diccionario = dict.fromkeys("123ABCDEF", "Significo")

print(diccionario)