#creando tuplas
tupla = tuple{["datos1","datos2"]}

#creando una tupla sin parentesis de multiples datos
tupla = "dato1","dato2"

#creando una tupla sin parentis de un solo dato
tupla = "dato",

print(tupla)