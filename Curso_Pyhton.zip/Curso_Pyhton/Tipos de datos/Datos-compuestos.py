lista = ["Lucas Dalto"," Soy Dalto", True, 1.85] #edita 
tupla = ("Lucas Dalto","Soy Dalto",True,1.85) #no edita


print(lista[3])

diccionario = { 
    'nombre' :  "Lucas Dalto",
    'canal' : "Soy Dalto",
    'esta_emocionado' : True
               }

print(diccionario['nombre'])