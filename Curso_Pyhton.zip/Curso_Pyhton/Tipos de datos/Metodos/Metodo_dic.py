diccionario = {
    "nombre" : "Lucas",
    "apellido" : "Sanchez",
    "suscripcion" : 1000000
}

#nos devuelve un elemento dict_item
claves = diccionario.keys()

print(claves)
