cadena1 = "bienVenido MasTodoNte, quinque, martillo de guerra"
cadena2 = "Hola soy yo"

#Convierte a mayuscula
resultado = cadena1.upper()

#convierte a miscula
resultado2 = cadena1.lower()

#convierte la primer letra
resultado3 = cadena1.capitalize()

#buscamos una cadena en otra cadena
busqueda_find = cadena1.find("t")

#cuenta la cantidad de veces que exise
contar = cadena1.count("en")  #.count() esto es metodo

#cuenta caracteres de cadenas
caracteres = len(cadena1) #funcion

#separa cadena
separe = cadena1.split(",")

print(resultado)
print(resultado2)
print(resultado3)
print(contar)
print(caracteres)
print(separe)