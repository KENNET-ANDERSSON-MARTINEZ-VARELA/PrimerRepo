lista = list(["Hola", "Kennet", 34,56,55,True])

#Devuelve la cantidad de elementos
cantidad_elementos = len(lista)

#agregando varios elementos a la lista
lista.extend([False, 1020, "vikingo"])

#Agregando un elemento a la lista
lista.append("Jaguar")

#agregando un elemento a la lista especifico
lista.insert(3,"TOMO MAPA")

#elimina un elemento de la lista
lista.pop(8) #para eliminar el ultimo -1 y para el siguiente -2 y asi

#elimina un elemento por su valor
lista.remove(False)

#ordena la lista ascendente en descendente pero solo numeros sino tira error
#lista.sort()

#invierte los elementos de la lista
lista.reverse()

#busca todas las cosas que se pueden hacer en la lista
#print(dir(lista))

print(lista)