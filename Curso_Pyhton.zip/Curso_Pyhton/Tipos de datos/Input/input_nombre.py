#pedirle un dato al usuario
nombre = input("che viejo, dame tu nombre:")

#mostrando el dato 
print(f"Mi nombre es: {nombre}")

