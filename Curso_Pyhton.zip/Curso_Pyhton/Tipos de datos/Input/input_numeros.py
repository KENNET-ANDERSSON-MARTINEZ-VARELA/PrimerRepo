#pedirle un numero al usuario
numero = input("Dame un numero:")

#convierto el numero a entero y lo multiplico por 2
resultado = int(numero) * 2

#convierto el numero a decimal y lo multiplico por 2
resultado = float(numero) * 2

# mostrando el resultado
print(resultado)
