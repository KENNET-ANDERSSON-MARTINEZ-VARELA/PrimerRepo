igual_que = 5==6

distinto_de = 5!=6

mayor_que = 5  > 6
menor_que = 5 < 6

mayor_igual = 5 >= 6

print(igual_que)

#calculos combinados
a = 5
b = 10
c = 20

comparacion = a + b < c

print(comparacion)

#comparar usuarios
contra_almacenada = "DaltoProfe"
contra_escrita = "Lucas"

print(contra_escrita == contra_almacenada)