suma = 12 + 5
resta = 10 - 6 

"elevado"
exponente = 9**5 

print (suma)
print(exponente)